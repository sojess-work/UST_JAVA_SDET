package com.sojess.libraryApp.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sojess.libraryApp.entity.Author;
import com.sojess.libraryApp.entity.Book;
import com.sojess.libraryApp.service.AuthorService;


@RestController
@RequestMapping("/api")
public class AuthorRestController {

	private AuthorService authorService;
	@Autowired
	public AuthorRestController(AuthorService authorService) {
		this.authorService= authorService;
	}
	
	@GetMapping("/authors")
	public List<Author> getAuthors(){
		
		return authorService.getAuthors();
	}
	
	@GetMapping("/authors/{authorId}")
	public String getAuthorByAuthorId(@PathVariable int authorId){
		
		return authorService.getAuthorByAuthorId(authorId).toString();
	}
	@GetMapping("/authors/{authorId}/{bookId}")
	public Book getBookByAuthorIdBookId(@PathVariable int authorId,@PathVariable int bookId){
		
		return authorService.getBookByAuthorIdBookId(authorId,bookId);
	}
	@GetMapping("/author/books/{authorId}")
	public List<Book> getBookByAuthorId(@PathVariable int authorId){
		
		return authorService.getBookByAuthorId(authorId);
	}
	
	@PostMapping("/authors")
public int saveAuthor(@RequestBody Author author) {
		author.setId(0);
		return authorService.saveOrUpdateAuthor(author);
	}
	
	@PutMapping("/authors")
	public int updateCustomer(@RequestBody Author author) {
		
		return authorService.saveOrUpdateAuthor(author);
	}
	
	@DeleteMapping("/authors/{authorId}")
	public String  deleteAuthor(@PathVariable int authorId) {
		
		Author author = authorService.getAuthorByAuthorId(authorId);
		if(author==null) {
			throw new RuntimeException("There is no user with id: "+authorId);
			
		}
		authorService.deleteAuthorById(authorId);
		return "Customer with id "+authorId+" deleted!";
	}
}
