package com.sojess.libraryApp.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sojess.libraryApp.entity.Publisher;
import com.sojess.libraryApp.service.PublisherService;


@RestController
@RequestMapping("/api")
public class PublisherRestController {

	
	private PublisherService publisherService;
	@Autowired
	public PublisherRestController(PublisherService publisherService) {
		this.publisherService= publisherService;
	}
	
	@GetMapping("/publishers")
	public List<Publisher> getPublishers(){
		return publisherService.getPublishers();
	}
	
	@GetMapping("/publishers/{publisherId}")
	public String getPublisherByPublisherId(@PathVariable int publisherId){
		
		return publisherService.getPublisherByPublisherId(publisherId).toString();
	}
}
