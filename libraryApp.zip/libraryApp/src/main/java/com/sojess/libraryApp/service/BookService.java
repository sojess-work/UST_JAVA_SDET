package com.sojess.libraryApp.service;

import java.util.List;

import com.sojess.libraryApp.entity.Author;
import com.sojess.libraryApp.entity.Book;

public interface BookService {

	public List<Book> getBooks();

	public Book getBooksByBookId(int id);

	public int saveOrUpdateBook(Book book);

	public void deleteBookById(int bookId);
}
