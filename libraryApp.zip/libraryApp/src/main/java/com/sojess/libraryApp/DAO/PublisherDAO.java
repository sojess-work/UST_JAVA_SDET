package com.sojess.libraryApp.DAO;

import java.util.List;

import com.sojess.libraryApp.entity.Publisher;

public interface PublisherDAO {

	public List<Publisher> getPublishers();
	
	public Publisher getPublisherByPublisherId(int publisherId);
}
