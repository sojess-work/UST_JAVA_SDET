package com.sojess.libraryApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sojess.libraryApp.DAO.BookDAO;
import com.sojess.libraryApp.entity.Author;
import com.sojess.libraryApp.entity.Book;

@Service
public class BookServiceImpl implements BookService {

	private BookDAO bookDAO;
	
	@Autowired
	public BookServiceImpl(BookDAO bookDAO) {
		this.bookDAO=bookDAO;
	}
	@Override
	@Transactional
	public List<Book> getBooks() {
		
		return bookDAO.getBooks();
	}
	@Override
	@Transactional
	public Book getBooksByBookId(int id) {
		
		return bookDAO.getBooksByBookId(id);
	}
	@Override
	@Transactional
	public int saveOrUpdateBook(Book book) {
		// TODO Auto-generated method stub
		return bookDAO.saveOrUpdateBook(book);
	}
	@Override
	@Transactional
	public void deleteBookById(int bookId) {
		bookDAO.deleteBookById(bookId);
		
	}

}
