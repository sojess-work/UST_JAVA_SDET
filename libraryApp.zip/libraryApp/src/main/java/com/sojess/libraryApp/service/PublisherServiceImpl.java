package com.sojess.libraryApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sojess.libraryApp.DAO.PublisherDAO;
import com.sojess.libraryApp.entity.Publisher;

@Service
public class PublisherServiceImpl implements PublisherService {
	
	private PublisherDAO publisherDAO;
	
	@Autowired
	public PublisherServiceImpl(PublisherDAO publisherDAO) {
		this.publisherDAO=publisherDAO;
	}

	@Override
	public List<Publisher> getPublishers() {
		
		return publisherDAO.getPublishers();
	}

	@Override
	public Publisher getPublisherByPublisherId(int publisherId) {
		
		return publisherDAO.getPublisherByPublisherId(publisherId);
				}

}
